<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="{{asset('css/user/normalize.css')}}" />
        <link rel="stylesheet" href="{{('css/user/master.css')}}" />
    <link rel="stylesheet" href="{{url('css/user/bootstrap.css')}}">
    <link rel="stylesheet" href="{{url('css/user/style.css')}}">
    <link rel="stylesheet" href="{{url('css/user/owl.carousel.min.css')}}">
    <link href="{{url('css/user/jquerysctipttop.css')}}" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="{{url('css/user/all.css')}}" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <title>The Magic</title>
</head>
<body>
