
<!--start footer------------------------------------------------------------------------------>
<footer class="footer">
  <div class="container">
    <div class="text-center">
      <a class="btn-floating btn-li mx-1" target="_blank" href="https://we-work.pro/"><h6 style="text-align: center">© 2021 All Rights are Reserved For The Magic Style Developed by we-work.pro 2022 By Eslam Elbanna </h6>                    </a></div>
  </div>

    @yield('script')
</footer>
<!--------------------------------------------------------------------------------end footer-->
