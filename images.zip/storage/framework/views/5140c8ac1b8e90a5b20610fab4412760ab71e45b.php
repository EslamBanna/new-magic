<!DOCTYPE html>
<html>
    <head>
        <title>Admin|Consultants</title>
        <!--*************Internal style sheet****************-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/admin/admin-users.css')); ?>" />
        
    </head>

<body class="vertical-layout vertical-menu 2-columns   menu-expanded fixed-navbar" data-open="click" data-menu="vertical-menu" data-color="bg-chartbg" data-col="2-columns">
<!--start side menue--------------------------------------------------------->
<?php echo $__env->make("admin.layouts.sidenav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-------------------------------------------------------end side menu-->

<!--start main-contenet---------------------------------------------------------->
<div class="content-wrapper">
  <div class="container-fluid">
      <!--start users traffic------------------------------------------------------------->
      <div class="row mt-3">
		<div class="col-12 col-lg-4 col-xl-4">
			<div class="card bg-primary  pull-up">
				<div class="card-body">
					<div class="media">
						<div class="media-body text-left">
							<h4 class="text-white mb-0"><?php echo e(count($organizers)); ?></h4>
							<span class="text-white">Total Organizers</span>
						</div>
						<div class="align-self-center w-circle-icon rounded border border-white">
							<i class="far fa-user text-white"></i></div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-12 col-lg-4 col-xl-4">
			<div class="card bg-success  pull-up">
				<div class="card-body">
					<div class="media">
						<div class="media-body text-left">
							<h4 class="text-white mb-0"><?php echo e($numOfAdmins); ?></h4>
							<span class="text-white">Admins</span>
						</div>
						<div class="align-self-center w-circle-icon rounded border border-white">
							<i class="fas fa-user-cog text-white"></i></div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-12 col-lg-4 col-xl-4">
			<div class="card bg-danger  pull-up">
				<div class="card-body">
					<div class="media">
						<div class="media-body text-left">
							<h4 class="text-white mb-0"><?php echo e(count($organizers)-$numOfAdmins); ?></h4>
							<span class="text-white">Consultants</span>
						</div>
						<div class="align-self-center w-circle-icon rounded border border-white">
							<i class="fas fa-user-shield text-white"></i></div>
					</div>
				</div>
			</div>
		</div>
	</div>
       <!-----------------------------------------------end of users traffic area-->
<!--start of recent orders-------------------------------------------------------------------->
 <div class="row">
    <div class="col-12 col-lg-12">
      <div class="card">
        <div class="card-header border-0">
           <div class="float-left"> <span>Recent Organizers</span> </div> 
           <div class="float-right"><a class="btn btn-outline-info" href="<?php echo e(route('organizers.create')); ?>"><i class="fas fa-user mr-1"></i>Add Organizer</a></div>  
        </div>      
           <div class="card-action">
              <div class="dropdown">
                <a  id="user-dropdown" class="collapse">
                  <i class="fas fa-ellipsis-h"></i>
                </a>
              </div>
           </div>
        <div class="table-responsive">
          <table class="table align-items-center table-flush table-hover">
              <thead>
                  <tr>
                    <!-- <th>Photo</th> -->
                    <th>#ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Date</th>
                    <th>Role</th>
                    <th>Action</th>
                  </tr>
              </thead>

              <tbody>
                <?php $__currentLoopData = $organizers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organizer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                   
                  <td><?php echo e($organizer->id); ?></td>
                  <td><?php echo e($organizer->name); ?></td>
                  <td>
                   <?php echo e($organizer->email); ?>

                  </td>
                  <td><?php echo e($organizer->phone); ?></td>
                  <td><?php echo e($organizer->created_at); ?></td>
                  <td>
                  <?php if($organizer['role']!=='admin'): ?>
                  <a href="<?php echo e(route('organizers.edit',$organizer)); ?>" title="edit"><i class="fas fa-user-edit" style="font-size:1rem;"></i></a><?php echo e($organizer->role); ?>

                  <p>Category :   <?php echo e($organizer->consultant_category); ?>


                  <?php else: ?>
                  <?php echo e($organizer->role); ?>

                  <?php endif; ?>
                  </td>
                  <?php if($organizer['role']!=='admin'): ?>

                  <td>
                     <!-- <i class="far fa-trash-alt " title="delete"></i> -->
                      <form action="<?php echo e(route('organizers.destroy',$organizer)); ?>" method="post">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field("delete"); ?>
                          <input type="submit" value="Delete" style="width: 85px" class="btn btn-outline-danger">
                      </form>
                   
                  </td>
                  <?php else: ?>
                  <td>

                  
                
              </td>
                  <?php endif; ?>
                </tr>
                  
                   
                         
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                   
         
              </tbody>
          </table>
        </div>
      </div>
    </div>
   </div> 
  
  

<!------------------------------------------------------------------------end of users-->


  </div>

</div>
<!-------------------------------------------------------------------------end main-contenet-->
<!--start footer------------------------------------------------------------------------------>
<?php echo $__env->make("admin.layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--------------------------------------------------------------------------------end footer-->
</div>

<!-----------------------------------------------------------end of main main page wrapper----------------------------------------->

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel projects\company\magic\new-magic\resources\views/admin/organizers.blade.php ENDPATH**/ ?>