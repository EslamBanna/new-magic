
<!--start footer------------------------------------------------------------------------------>
<footer class="footer">
  <div class="container">
    <div class="text-center">
      <a class="btn-floating btn-li mx-1" target="_blank" href="https://we-work.pro/"><h6 style="text-align: center">© 2021 All Rights are Reserved For The Magic Style Developed by we-work.pro 2022 By Eslam Elbanna </h6>                    </a></div>
  </div>

    <?php echo $__env->yieldContent('script'); ?>
</footer>
<!--------------------------------------------------------------------------------end footer-->
<?php /**PATH C:\xampp\htdocs\laravel projects\company\magic\new-magic\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>