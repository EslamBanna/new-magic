<!DOCTYPE html>
<html>
    <head>
        <title>Admin|Consultants</title>
        <!--*************Internal style sheet****************-->
        <link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/admin/admin-users.css')); ?>" />
        
    </head>

<body class="vertical-layout vertical-menu 2-columns   menu-expanded fixed-navbar" data-open="click" data-menu="vertical-menu" data-color="bg-chartbg" data-col="2-columns">
<!--start side menue--------------------------------------------------------->
<?php echo $__env->make("admin.layouts.sidenav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-------------------------------------------------------end side menu-->

<!--start main-contenet---------------------------------------------------------->
<div class="content-wrapper">
  <div class="container-fluid">
      <!--start users traffic------------------------------------------------------------->
      <div class="row mt-3">
		<div class="col-12 col-lg-4 col-xl-4">
			<div class="card bg-primary  pull-up">
				<div class="card-body">
					<div class="media">
						<div class="media-body text-left">
							<h4 class="text-white mb-0"><?php echo e(count($all_tests)); ?></h4>
							<span class="text-white">Total Tests</span>
						</div>
						<div class="align-self-center w-circle-icon rounded border border-white">
							<i class="far fa-user text-white"></i></div>
					</div>
				</div>
			</div>
		</div>
	
	</div>
       <!-----------------------------------------------end of users traffic area-->
<!--start of recent orders-------------------------------------------------------------------->
 <div class="row">
    <div class="col-12 col-lg-12">
      <div class="card">
        <div class="card-header border-0">
           <div class="float-left"> <span>All Consult Tests</span> </div> 
       
        </div>      
           <div class="card-action">
              <div class="dropdown">
                <a  id="user-dropdown" class="collapse">
                  <i class="fas fa-ellipsis-h"></i>
                </a>
              </div>
           </div>
        <div class="table-responsive">
          <table class="table align-items-center table-flush table-hover">
              <thead>
                  <tr style="color:blue; background-color:yellow;text-align:center">
                    <!-- <th>Photo</th> -->
                    <th>#ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                      <th>Age</th>
                    <th>Job</th>
                    <th>Social Status</th>
                      <th>Apperance</th>
                    <th>Feel</th>
                    <th>Interest</th>
                      <th>Budget</th>
                    <th>Amount</th>
                    <th>Brand</th>
                    
                      <th>Formats</th>
                      <th>Want during consultation</th>
                    <th>Consultation type</th>
                    <th>Consultation Price</th>
                    
                    <th>User Id</th>
                    
                    
                    
                  
                  </tr>
              </thead>

              <tbody>
                <?php $__currentLoopData = $all_tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="text-align:center">
                   
                  <td><?php echo e($test->id); ?></td>
                  <td><?php echo e($test->name); ?></td>
                  <td>
                   <?php echo e($test->email); ?>

                  </td>
                  <td><?php echo e($test->phone); ?></td>
                  
                   <td><?php echo e($test->age); ?></td>
                  <td><?php echo e($test->job); ?></td>
                  <td>
                   <?php echo e($test->social_status); ?>

                  </td>
                  <td><?php echo e($test->apperance); ?></td>
                  
                   <td><?php echo e($test->feel); ?></td>
                  <td><?php echo e($test->interest); ?></td>
                  <td>
                   <?php echo e($test->budget); ?>

                  </td>
                  <td><?php echo e($test->amount); ?></td>
                  
                  
                   <td><?php echo e($test->brand); ?></td>
                  <td><?php echo e($test->formats); ?></td>
                  <td>
                   <?php echo e($test->want); ?>

                  </td>
                  
                  
                  <?php
                    
                     $conslt =  App\Models\CunsultantPackages::where('id',$test->consult_id)->first();
                  
                  ?>
                  <td><?php if(!empty($conslt)): ?> <?php echo e($conslt->consultation_type); ?> <?php else: ?> ' '  <?php endif; ?></td>
                  
                  
                  
                  <td><?php if($test->consult_price==0): ?> free <?php else: ?><?php echo e($test->consult_price); ?> <?php endif; ?></td>
                
                  
                  
                   <td><?php echo e($test->user_id); ?></td>
                
               
               
                
                </tr>
                  
                   
                         
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                   
         
              </tbody>
          </table>
        </div>
      </div>
    </div>
   </div> 
  
  

<!------------------------------------------------------------------------end of users-->


  </div>

</div>
<!-------------------------------------------------------------------------end main-contenet-->
<!--start footer------------------------------------------------------------------------------>
<?php echo $__env->make("admin.layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--------------------------------------------------------------------------------end footer-->
</div>

<!-----------------------------------------------------------end of main main page wrapper----------------------------------------->

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel projects\company\magic\new-magic\resources\views/admin/consult_tests.blade.php ENDPATH**/ ?>